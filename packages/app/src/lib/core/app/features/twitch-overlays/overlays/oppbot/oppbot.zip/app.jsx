import React, { useState, useEffect } from 'https://esm.sh/react@18.2.0';
import ReactDOM from 'https://esm.sh/react-dom@18.2.0/client';
import sortBy from "https://cdn.skypack.dev/lodash-es/sortBy";
import { getConnection } from './scripts/websocket.js';
import { getRacePrefix, getLeaderboardStat } from './scripts/helpers.js';
import { data_2v2 } from './scripts/data.js';

const FACTION = ['US', 'WM', 'UK', 'PE'];

const getRaceImage = (race) => {
    const map = ['./images/us.png', './images/wm.png', './images/cw.png', './images/pe.png'];
    return map[race] ?? map[0];
};

const getRankImage = (type, player) => {
    const stat = getLeaderboardStat(type, player);
    if (!stat || stat.ranklevel < 1) return './images/ranks/no_rank_yet.png';
    const prefix = getRacePrefix(player.race);
    return `./images/ranks/${prefix}_${stat.ranklevel.toString().padStart(2, '0')}.png`;
};

const formatRanking = (ranking) => {
    if (!ranking || ranking < 1) return '—';
    return `#${ranking.toLocaleString()}`;
};

const formatElo = (ranktotal) => {
    if (typeof ranktotal !== 'number' || ranktotal < 1) return null;
    return ranktotal.toLocaleString();
};

const getCombatRecord = (type, player) => {
    const stat = getLeaderboardStat(type, player);
    if (!stat) return { wins: 0, losses: 0, winRate: null, streak: 0, elo: null };

    const wins = Math.max(0, stat.wins ?? 0);
    const losses = Math.max(0, stat.losses ?? 0);
    const total = wins + losses;
    const winRate = total > 0 ? Math.round((wins / total) * 100) : null;
    const streak = typeof stat.streak === 'number' ? stat.streak : 0;
    const elo = formatElo(stat.ranktotal);

    return { wins, losses, winRate, streak, elo };
};

const formatStreak = (streak) => {
    if (!streak) return null;
    return streak > 0 ? `+${streak}` : `${streak}`;
};

/**
 * @param {{ player: import('./scripts/helpers.js').Player, matchType: number, teamIndex: number, isMe: boolean }} props
 */
const Unit = ({ player, matchType, teamIndex, isMe }) => {
    const alias = player.profile?.alias ?? 'CPU';
    const country = player.profile?.country;
    const rec = getCombatRecord(matchType, player);
    const streak = formatStreak(rec.streak);

    return (
        <article className={`unit side-${teamIndex}${isMe ? ' unit--self' : ''}`}>
            <div className="unit__seal">
                <img src={getRankImage(matchType, player)} alt="" />
            </div>

            <div className="unit__panel">
                <div className="unit__primary">
                    {country && (
                        <img
                            className="unit__flag"
                            src={`https://flagsapi.com/${country.toUpperCase()}/flat/64.png`}
                            alt={country}
                        />
                    )}
                    <span className="unit__name" title={alias}>{alias}</span>
                    <span className="unit__scores">
                        <span className="unit__ranking">{formatRanking(player.ranking)}</span>
                        {rec.elo && <span className="unit__elo">{rec.elo} ELO</span>}
                    </span>
                </div>

                <div className="unit__secondary">
                    <span className="unit__faction">
                        <img src={getRaceImage(player.race)} alt="" />
                        {FACTION[player.race]}
                    </span>
                    <span className="unit__record">
                        <span className="unit__w">{rec.wins}W</span>
                        <span className="unit__l">{rec.losses}L</span>
                        {rec.winRate !== null && <span className="unit__wr">{rec.winRate}%</span>}
                        {streak && (
                            <span className={`unit__streak${rec.streak > 0 ? ' unit__streak--up' : ' unit__streak--down'}`}>
                                {streak}
                            </span>
                        )}
                    </span>
                </div>
            </div>
        </article>
    );
};

const Side = ({ team, index, matchType, meId }) => (
    <aside className={`side side-${index}`}>
        <div className="side__units">
            {team.players.map((player, i) => (
                <Unit
                    key={player.playerId || i}
                    player={player}
                    matchType={matchType}
                    teamIndex={index}
                    isMe={meId != null && player.playerId === meId}
                />
            ))}
        </div>
    </aside>
);

const App = () => {
    const [data, setData] = useState();

    useEffect(() => {
        const init = async () => {
            const socket = await getConnection('ws://localhost:9842/ws');
            socket.send(JSON.stringify({ type: 'subscribe', topic: 'game.lobby.started' }));
            socket.send(JSON.stringify({ type: 'subscribe', topic: 'game.lobby.destroyed' }));

            socket.addEventListener('message', (event) => {
                const { data: newData, type, topic } = JSON.parse(event.data);

                if (type === 'message' && topic === 'game.lobby.destroyed') {
                    setData(null);
                    return;
                }

                if (type === 'message' && topic === 'game.lobby.started') {
                    newData.teams = sortBy(newData.teams, (t) =>
                        t.players.find((p) => p.playerId === newData.me?.playerId) ? 0 : 1
                    );
                    setData(newData);
                }
            });
        };
        init();
    }, []);

    if (!data) return null;

    const playerCount = data.players?.length || data.teams?.reduce((sum, t) => sum + (t.players?.length || 0), 0) || 0;

    return (
        <div className="manifest">
            <div className={`manifest__field count-${playerCount}`}>
                {data.teams?.map((team, index) => (
                    <Side key={index} team={team} index={index} matchType={data.matchType} meId={data.me?.playerId} />
                ))}
            </div>
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('app'));
root.render(<App />);
