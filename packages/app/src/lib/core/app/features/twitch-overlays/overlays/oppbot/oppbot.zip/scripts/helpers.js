export const LEADERBOARD_IDS = {
	'Custom Game_us': 0,
	'Custom Game_heer': 1,
	'Custom Game_brit': 2,
	'Custom Game_panzer': 3,
	'1v1_us': 4,
	'1v1_heer': 5,
	'1v1_brit': 6,
	'1v1_panzer': 7,
	'2v2_us': 8,
	'2v2_heer': 9,
	'2v2_brit': 10,
	'2v2_panzer': 11,
	'3v3_us': 12,
	'3v3_heer': 13,
	'3v3_brit': 14,
	'3v3_panzer': 15,
	'4v4_us': 16,
	'4v4_heer': 17,
	'4v4_brit': 18,
	'4v4_panzer': 19
}

export const MATCH_TYPES = {
	0: 'Custom Game',
	1: '1v1',
	2: '2v2',
	3: '3v3',
	4: '4v4',
	5: '2v2 AT',
	6: '3v3 AT',
	7: '4v4 AT',
	8: 'Assault 2v2',
	9: 'Assault 2v2 AT',
	10: 'Assault 3v3 AT',
	11: 'Panzerkrieg 2v2',
	12: 'Panzerkrieg 2v2 AT',
	13: 'Panzerkrieg 3v3 AT',
	14: 'Comp Stomp',
	15: 'Assault',
	16: 'Panzerkrieg',
	17: 'Stonewall'
}

/**
 * Get race prefix
 * 
 * @param {0 | 1 | 2 | 3} race 
 */
export const getRacePrefix = (race) => {
    switch(race) {
        case 0:
            return 'us';
        case 1:
            return 'heer';
        case 2:
            return 'brit';
        case 3:
            return 'panzer';
        default:
            return 'us';
    }
}

/**
 * Which side of the war a faction belongs to.
 * US Forces (0) and British (2) are Allies; Wehrmacht (1) and Panzer Elite (3) are Axis.
 *
 * @param {0 | 1 | 2 | 3} race
 * @returns {'allied' | 'axis'}
 */
export const getFactionSide = (race) => {
    return race === 1 || race === 3 ? 'axis' : 'allied';
}

/**
 * Resolve the leaderboard stat entry that matches the current match type and the
 * player's race. Used for the rank badge as well as win/loss/streak figures.
 *
 * @param {number} type - The match type id (see MATCH_TYPES)
 * @param {import('../app.jsx').Player | { race: number, profile?: { leaderboardStats?: LeaderboardStat[] } }} player
 * @returns {LeaderboardStat | null}
 */
export const getLeaderboardStat = (type, player) => {
    const prefix = getRacePrefix(player.race);
    const leaderBoardId = LEADERBOARD_IDS[`${MATCH_TYPES[type]}_${prefix}`];

    const statGroup = player.profile?.leaderboardStats?.find(
        (stat) => stat.leaderboard_id === leaderBoardId
    );
	
    return statGroup ?? null;
}

/**
 * Resolve the player's current ELO from their most recent ranked match of the
 * same type and faction. `leaderboardStats.ranktotal` is often stale; `matchHistory`
 * carries the post-match `newrating` per game mode and race.
 *
 * @param {number} matchType - The lobby match type id (see MATCH_TYPES)
 * @param {import('./helpers.js').Player} player
 * @returns {number | null}
 */
export const getPlayerEloFromMatchHistory = (matchType, player) => {
    const history = player.matchHistory;
    if (!history?.length) return null;

    const profileId = player.playerId ?? player.profile?.profile_id;
    if (profileId == null) return null;

    let elo = null;
    let latestCompletion = -1;

    for (const match of history) {
        if (match.matchtype_id !== matchType) continue;

        const entry = match.players?.find(
            (p) => p.profile_id === profileId && p.race_id === player.race
        );
        if (!entry || typeof entry.newrating !== 'number' || entry.newrating < 1) continue;

        const completed = match.completiontime ?? match.startgametime ?? 0;
        if (completed >= latestCompletion) {
            latestCompletion = completed;
            elo = entry.newrating;
        }
    }

    return elo;
}

/**
 * @typedef {Object} LeaderboardStat
 * @property {number} disputes
 * @property {number} drops
 * @property {number} highestrank
 * @property {number} highestranklevel
 * @property {number} [lastmatchdate]
 * @property {number} leaderboard_id
 * @property {number} losses
 * @property {number} rank
 * @property {number} ranklevel
 * @property {number} ranktotal
 * @property {number} regionrank
 * @property {number} regionranktotal
 * @property {number} statgroup_id
 * @property {number} streak
 * @property {number} wins
 */

/**
 * @typedef {Object} PlayerProfile
 * @property {string} alias
 * @property {string} country
 * @property {LeaderboardStat[]} leaderboardStats
 * @property {number} leaderboardregion_id
 * @property {number} level
 * @property {string} name
 * @property {number} personal_statgroup_id
 * @property {number} profile_id
 * @property {number} xp
 */

/**
 * @typedef {Object} MatchHistoryPlayer
 * @property {number} profile_id
 * @property {number} newrating
 * @property {number} oldrating
 * @property {number} race_id
 * @property {string} [steamId]
 */

/**
 * @typedef {Object} MatchHistoryEntry
 * @property {number} matchtype_id
 * @property {number} [completiontime]
 * @property {number} [startgametime]
 * @property {MatchHistoryPlayer[]} players
 */

/**
 * @typedef {Object} Player
 * @property {number} index
 * @property {number} playerId
 * @property {PlayerProfile} profile
 * @property {number} race - Race ID (0: US, 1: Wehrmacht, 2: Commonwealth, 3: Panzer Elite)
 * @property {number} ranking
 * @property {string} steamId
 * @property {number} team
 * @property {number} type
 * @property {MatchHistoryEntry[]} [matchHistory]
 */