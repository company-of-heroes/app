import { getConnection } from './scripts/websocket.js';

const socket = await getConnection('ws://localhost:9842/ws');

socket.send(JSON.stringify({ type: 'subscribe', topic: 'twitch.viewers' }));

socket.addEventListener('message', (event) => {
    console.log(JSON.parse(event.data));

    const { data, type, topic } = JSON.parse(event.data);
    const counter = document.querySelector('.counter');
    
    if (topic !== 'twitch.viewers' && type !== 'message') {
        return;
    }

    counter.textContent = data.count;
});