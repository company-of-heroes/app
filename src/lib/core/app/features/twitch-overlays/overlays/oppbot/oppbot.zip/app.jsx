import React, { useState, useEffect } from 'https://esm.sh/react@18.2.0';
import ReactDOM from 'https://esm.sh/react-dom@18.2.0/client';
import sortBy from "https://cdn.skypack.dev/lodash-es/sortBy";
import { getConnection } from './scripts/websocket.js';
import { LEADERBOARD_IDS, MATCH_TYPES, getRacePrefix } from './scripts/helpers.js';
import { data_2v2 } from './scripts/data.js';

const getRaceImage = (race) => {
    if (race === 0) return './images/us.png';
    if (race === 1) return './images/wm.png';
    if (race === 2) return './images/cw.png';
    if (race === 3) return './images/pe.png';
    return './images/us.png';
};

const getRankImage = (type, player) => {
    const prefix = getRacePrefix(player.race);
    const leaderBoardId = LEADERBOARD_IDS[`${MATCH_TYPES[type]}_${prefix}`];
    const statGroup = player.profile?.leaderboardStats?.find(
        (stat) => stat.leaderboard_id === leaderBoardId
    );

    if (!statGroup || statGroup.ranklevel < 1) {
        return './images/ranks/no_rank_yet.png';
    }

    return `./images/ranks/${prefix}_${statGroup.ranklevel.toString().padStart(2, '0')}.png`;
};

/**
 * Display a player
 * 
 * @param {{ player: import('./scripts/helpers.js').Player, matchType: string }} props 
 * @returns {JSX.Element}
 */
const Player = ({ player, matchType }) => {
    return (
        <span className="player">
            <span className="profile">
                {player.profile && player.profile.country && (
                    <img
                        className="country-flag"
                        src={`https://flagsapi.com/${player.profile.country.toUpperCase()}/flat/64.png`}
                        alt={player.profile.country}
                    />
                )}
                <span className="ranking">{player.ranking ? player.ranking : '-1'}</span>
                <img
                    className="rank"
                    src={getRankImage(matchType, player)}
                    alt="rank-image"
                />
                <img src={getRaceImage(player.race)} className="race" />
                <span className="alias">{player.profile?.alias ? player.profile.alias : 'CPU'}</span>
            </span>
        </span>
    );
};

const Team = ({ team, index, matchType }) => {
    return (
        <div className={`team team-${index}`}>
            {team.players.map((player, pIndex) => (
                <Player key={player.playerId || pIndex} player={player} matchType={matchType} />
            ))}
        </div>
    );
};

const App = () => {
    const [data, setData] = useState(data_2v2);

    useEffect(() => {
        const init = async () => {
            const socket = await getConnection('ws://localhost:9842/ws');
            socket.send(JSON.stringify({ type: 'subscribe', topic: 'game.lobby.started' }));
            socket.send(JSON.stringify({ type: 'subscribe', topic: 'game.lobby.destroyed' }));

            socket.addEventListener('message', (event) => {
                let { data: newData, type, topic } = JSON.parse(event.data);

                if (type === 'message' && topic === 'game.lobby.destroyed') {
                    setData(null);
                    return;
                }

                if (type === 'message' && topic === 'game.lobby.started') {
                    newData.teams = sortBy(newData.teams, (t) => (t.players.find((p) => p.playerId === newData.me?.playerId) ? 0 : 1));
                }

                setData(newData);
            });
        };
        init();
    }, []);

    if (!data) return null;

    return (
        <div className={`overlay-${data.players?.length || 0}`}>
            {data.teams?.map((team, index) => (
                <Team key={index} team={team} index={index} matchType={data.matchType} />
            ))}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('app'));
root.render(<App />);
