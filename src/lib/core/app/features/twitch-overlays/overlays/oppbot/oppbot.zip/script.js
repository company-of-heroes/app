// import { data_4v4 } from './scripts/data.js';
import sortBy from "https://cdn.skypack.dev/lodash-es/sortBy";
import { getConnection } from './scripts/websocket.js';
import './scripts/handlebars.js';

const socket = await getConnection('ws://localhost:9842/ws');
const request = await fetch('./template.hbs');
const html = await request.text();
const template = Handlebars.compile(html);  

socket.send(JSON.stringify({ type: 'subscribe', topic: 'game.lobby.started' }));
socket.send(JSON.stringify({ type: 'subscribe', topic: 'game.lobby.destroyed' }));

socket.addEventListener('message', (event) => {
    let { data, type, topic } = JSON.parse(event.data);
    // data = data_4v4;
    app.innerHTML = template(data);
    if (type === 'message' && topic === 'game.lobby.started') {
        // Make sure I am always on the left side of the VP's
        data.teams = sortBy(data.teams, (t) => (t.players.find((p) => p.playerId === data.me?.playerId) ? 0 : 1))
        app.innerHTML = template(data);
    }

    if (type === 'message' && topic === 'game.lobby.destroyed') {
        app.innerHTML = '';
    }
});