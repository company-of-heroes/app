let ws;
let interval = setInterval(() => {
    ws = new WebSocket('ws://localhost:9842/ws');
	ws.addEventListener('open', () => {
		const app = document.getElementById('app');
        clearInterval(interval);

		ws.send(JSON.stringify({ type: 'subscribe', topic: 'twitch.chat' }));

		ws.addEventListener('message', (event) => {
			const { data, type, topic } = JSON.parse(event.data);
			console.log(type, JSON.parse(event.data))

			if (type === 'message' && topic === 'twitch.chat') {
				const message = `<div class="message">
					<span class="username">
						${data.user}
					</span>
					<span class="text">${data.message}</span>
				</div>`
				app.insertAdjacentHTML('beforeend', message)
			}
		});
	});

    ws.addEventListener('error', (error) => {
        console.log('WebSocket error:', error);
    });

    ws.addEventListener('close', (event) => {
        console.log('WebSocket closed:', event.code, event.reason);
        if (!interval) {
            interval = setInterval(arguments.callee, 1000);
        }
    });
    
}, 1000);